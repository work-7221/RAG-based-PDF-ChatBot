import streamlit as st

page_1 = st.Page("Chat_History_Selection.py")
page_2 = st.Page("application.py")

navigate = st.navigation([page_1, page_2], position = "hidden")



# col1, col2 = st.columns([1, 1])

# with col1:
#     if st.button("Home"):
#         st.switch_page("Chat_History_Selection.py")


navigate.run()