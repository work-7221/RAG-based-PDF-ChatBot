import streamlit as st
from pathlib import Path

st.title("Chats")

if "control" not in st.session_state:
    st.session_state.control = 0


if "chat_list" not in st.session_state:
    st.session_state.chat_list = []

if "buttons" not in st.session_state:
    st.session_state.buttons = []

dir_path = Path(r"C:\My_Folder_Rohan\Rohan\Hell_Yeah\Personal_Projects\RAG based PDFChatBot\Chat_History")


id = 0
if st.session_state.control < 1:
    for chat in dir_path.iterdir():
        if chat.is_file():
            # st.session_state.chat_list.append(chat.name)
            btn = st.button(chat.name, key = id)
            id += 1

st.session_state.control = 1